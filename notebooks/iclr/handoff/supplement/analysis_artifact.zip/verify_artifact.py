import hashlib,json,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parent
m=json.loads((root/"artifact_manifest.json").read_text())
for name,item in m["files"].items():
 assert hashlib.sha256((root/name).read_bytes()).hexdigest()==item["distributed_sha256"],name
for command in [['check_band_provenance.py'], ['build_mixing_tables.py', '--check'], ['build_focused_tables.py', '--check'], ['analyze_focused_confirmation.py', '--check'], ['analyze_final_evidence.py', '--check'], ['analyze_review_v2.py', '--check'], ['check_spectral_algebra.py'], ['analyze_review_v3.py', '--check'], ['build_tail_story_tables.py', '--check'], ['build_interaction_outcomes_figure.py', '--check'], ['check_review_additions.py'], ['audit_manuscript.py']]:
 subprocess.run([sys.executable,"scripts/"+command[0],*command[1:]],cwd=root,check=True)
print("PASS: distributed hashes and all analysis checks.")
