# Supplementary analysis archive

Run `python3 verify_artifact.py` from this directory after installing requirements.txt.
The checks use CPU only, do not fetch remote data, and do not require Git history.
Optional PDF build: `tectonic -X compile neurips_2026.tex --keep-logs`;
then `python3 scripts/audit_manuscript.py --pdf neurips_2026.pdf`.

Contents: paper sources/styles, exported measurements, thirteen distinct-recipe
manifests, selection frontier, invalidation/preparation records, 18 held-aside
per-example prediction/label/loss records, analysis/regeneration scripts, figures,
and hash-checked historical table fixtures. The GLUE CSV preserves 60 original
means/SDs; imported rows use the RandLoRA protocol, spectral rows use the historical
protocol with unresolved run/count provenance. MRPC in that table is accuracy.
The inactive retention table is an exclusion/provenance record, not paper evidence.
All 21 registered RTE band/head confirmations are included with their freeze
ledger, plus two separately labeled timing pilots. Band scores are inner-selection
scores; official held-aside scoring of this block is absent from this release.
Do not pool pilots with confirmations or band scores with the separate 18-run
practical held-aside evaluation.

This is a sanitized derivative, not the untouched server export. Private path
prefixes, project labels and GPU identifiers are replaced. Run IDs, seeds, steps,
numerical measurements, source revisions, and checkpoint/validation hashes remain.
artifact_manifest.json records both source and distributed hashes for copied files.
The distributed held-aside request/manifest has hashes rebound to sanitized copies;
it does not constitute a new preregistration. Generated analysis hashes refer to
distributed bytes. SHA checks establish consistency, not independent authenticity.

The experiment_source directory includes the 46 recorded Python source files,
including the training runner and its tests. The ten recorded band-run source
revisions have identical campaign trees, and their source fingerprints were
checked against Git blobs. The two files containing a private project identifier
are anonymized in this archive; both original and distributed hashes are retained.
See experiment_source/README.md for the scope of this source snapshot.

No model weights, raw dataset text, original validation reports,
full protocol-registration documents, or complete historical run manifests are
included. Checkpoint hashes identify unavailable upstream artifacts;
they do not make those artifacts downloadable. These scripts reproduce analysis
of the exports, not training, checkpoint validation, or independently timed execution.
Centered-scaler experiments, temperature-scaling logits and full training curves
are not included. No claim about their outcomes is made.
This archive is prepared for author delivery as supplementary material; it does
not assert that a public repository or anonymous hosting endpoint already exists.
